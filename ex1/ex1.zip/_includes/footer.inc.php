<div id="footer">
  Copyright ©2018, Josh Spurling
</div>
</div>
