<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21811/CIT313/ex5/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'jjspurli');
define('DB_PASS', 'survive1');
define('DB_NAME', 'jjspurli_db');

define('REQFIELD', '<font color="#FF0000">*</font>');
?>
